"""Creates a SYNTHETIC demo dataset (data/flights.csv).

IMPORTANT: this is NOT real airline data. Prices come from a simple made-up
formula plus random noise, only so the prototype can run end to end without
downloading anything. For your final submission, put your real dataset at
data/flights.csv (same column names, see README.md) and re-run train.py.
"""
import os
import numpy as np
import pandas as pd

# Approximate distances in km between a few Indian cities (used only by the formula)
DIST = {
    ("Delhi", "Mumbai"): 1150, ("Delhi", "Bangalore"): 1750, ("Delhi", "Kolkata"): 1320,
    ("Delhi", "Chennai"): 1760, ("Delhi", "Hyderabad"): 1250, ("Mumbai", "Bangalore"): 840,
    ("Mumbai", "Kolkata"): 1650, ("Mumbai", "Chennai"): 1030, ("Mumbai", "Hyderabad"): 620,
    ("Bangalore", "Kolkata"): 1560, ("Bangalore", "Chennai"): 290, ("Bangalore", "Hyderabad"): 500,
    ("Kolkata", "Chennai"): 1360, ("Kolkata", "Hyderabad"): 1190, ("Chennai", "Hyderabad"): 520,
}
AIRLINE_FACTOR = {
    "IndiGo": 1.00, "Air India": 1.25, "SpiceJet": 0.95,
    "Akasa Air": 0.97, "Air India Express": 0.90,
}


def km(a: str, b: str) -> int:
    return DIST.get((a, b)) or DIST[(b, a)]


def generate(n: int = 8000, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    cities = sorted({c for pair in DIST for c in pair})
    airlines = list(AIRLINE_FACTOR)

    rows = []
    for _ in range(n):
        src, dst = rng.choice(cities, size=2, replace=False)
        airline = rng.choice(airlines)
        stops = int(rng.choice([0, 1, 2], p=[0.55, 0.37, 0.08]))
        date = pd.Timestamp("2026-01-01") + pd.Timedelta(days=int(rng.integers(0, 365)))
        hour, minute = int(rng.integers(0, 24)), int(rng.choice([0, 15, 30, 45]))
        distance = km(src, dst)

        duration = int(max(50, distance / 750 * 60 + 45 + stops * 110 + rng.normal(0, 10)))

        price = 1500 + 3.1 * distance
        price *= AIRLINE_FACTOR[airline]
        price *= 1 + 0.15 * stops
        price *= 1.15 if date.month in (5, 6, 10, 11, 12) else 1.0
        price *= 1.08 if date.weekday() >= 4 else 1.0
        price *= 1.07 if (6 <= hour <= 9 or 17 <= hour <= 21) else 1.0
        price *= rng.lognormal(0, 0.08)

        rows.append({
            "Airline": airline, "Source": src, "Destination": dst,
            "Date_of_Journey": date.strftime("%Y-%m-%d"),
            "Dep_Time": f"{hour:02d}:{minute:02d}",
            "Duration_Min": duration, "Total_Stops": stops,
            "Price": int(round(price)),
        })
    return pd.DataFrame(rows)


if __name__ == "__main__":
    os.makedirs("data", exist_ok=True)
    generate().to_csv("data/flights.csv", index=False)
    open("data/.synthetic", "w").close()  # marker: tells train.py this CSV is synthetic
    print("Synthetic demo data written to data/flights.csv")
