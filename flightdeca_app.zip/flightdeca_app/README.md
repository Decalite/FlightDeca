# FlightDeca: Intelligent Flight Fare Prediction (Prototype)

BTech CSE · AI Applications Lab. A Flask web app that predicts a flight fare with a scikit-learn Random Forest Regressor.

## Run locally

```bash
pip install -r requirements.txt
python train.py        # trains the model, writes model/ (creates synthetic demo data if data/flights.csv is missing)
python app.py          # open http://127.0.0.1:5000
python test_app.py     # optional: quick API checks
```

## Important: demo data vs real data

`generate_sample_data.py` creates a **synthetic** dataset from a made-up price formula so the prototype runs without downloads.
Its fares and the metrics shown on the site are **not real**. For your submission:

1. Put your real dataset at `data/flights.csv` (delete `data/.synthetic`).
2. Make sure it has these columns (rename/convert yours if needed):

| Column | Format |
|---|---|
| Airline, Source, Destination | text |
| Date_of_Journey | `YYYY-MM-DD` |
| Dep_Time | `HH:MM` (24-hour) |
| Duration_Min | integer minutes |
| Total_Stops | integer (0, 1, 2 ...) |
| Price | number (target) |

3. Run `python train.py` again. The site then shows your real metrics.

## Project structure

```
app.py                    Flask server + /api/predict + /api/model-info
train.py                  preprocessing, Random Forest training, evaluation, saves model
features.py               feature engineering shared by training and prediction
generate_sample_data.py   synthetic demo data (replace with real data)
templates/index.html      page (Jinja)
static/style.css, app.js  styling and the fetch() call to the API
test_app.py               API checks
```

## How prediction works

1. The form sends journey details to `POST /api/predict`.
2. `features.py` converts them (day, month, weekday, hour, duration in minutes, stops) exactly as in training.
3. The saved pipeline (one-hot encoding + `RandomForestRegressor`, 150 trees) predicts the fare.
4. The "tree spread" is the 10th to 90th percentile of the individual trees' predictions. It is not a statistical confidence interval.

## Get a shareable link (deploy)

Flask needs a Python server, so it cannot run on plain static hosting. Free options:

- **Render** (render.com): push this folder to GitHub, create a *Web Service*, build command `pip install -r requirements.txt && python train.py`, start command `gunicorn app:app`.
- **PythonAnywhere**: upload the folder, create a Flask web app pointing to `app.py`, run `python train.py` once in a console.
