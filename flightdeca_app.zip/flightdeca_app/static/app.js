// Sends the form to the Flask API (/api/predict) and shows the returned fare.
const form = document.getElementById("fare-form");
const btn = document.getElementById("predict-btn");
const resultBox = document.getElementById("result");
const errorBox = document.getElementById("error");

// Default the date to tomorrow
const dateInput = form.elements["date"];
const tomorrow = new Date(Date.now() + 86400000);
dateInput.value = tomorrow.toISOString().slice(0, 10);

const rupees = (n) => "₹" + n.toLocaleString("en-IN");

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  errorBox.hidden = true;
  resultBox.hidden = true;

  const payload = Object.fromEntries(new FormData(form).entries());
  if (payload.source === payload.destination) {
    errorBox.textContent = "Source and destination must be different.";
    errorBox.hidden = false;
    return;
  }

  btn.disabled = true;
  btn.textContent = "Predicting...";
  try {
    const res = await fetch("/api/predict", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Prediction failed.");

    document.getElementById("price").textContent = rupees(data.predicted_fare);
    document.getElementById("range").textContent =
      `Tree spread (10th–90th percentile of ${data.n_trees} trees): ` +
      `${rupees(data.tree_spread_low)} – ${rupees(data.tree_spread_high)}`;
    resultBox.hidden = false;
  } catch (err) {
    errorBox.textContent = err.message;
    errorBox.hidden = false;
  } finally {
    btn.disabled = false;
    btn.textContent = "Predict fare";
  }
});
