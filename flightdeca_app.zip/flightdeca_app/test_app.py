"""Quick checks for the FlightDeca API.  Run:  python test_app.py"""
from app import app, META

client = app.test_client()
good = {
    "airline": META["airlines"][0], "source": "Delhi", "destination": "Mumbai",
    "date": "2026-12-20", "dep_time": "18:30",
    "duration_hours": 2, "duration_minutes": 10, "stops": 0,
}

# 1. Home page loads
assert client.get("/").status_code == 200

# 2. A valid request returns a fare
r = client.post("/api/predict", json=good)
assert r.status_code == 200, r.get_json()
out = r.get_json()
assert out["predicted_fare"] > 0
assert out["tree_spread_low"] <= out["tree_spread_high"]
print("Predicted fare:", out)

# 3. Same city for source and destination is rejected
bad = dict(good, destination="Delhi")
assert client.post("/api/predict", json=bad).status_code == 400

# 4. Missing field is rejected
assert client.post("/api/predict", json={"airline": good["airline"]}).status_code == 400

print("All checks passed.")
