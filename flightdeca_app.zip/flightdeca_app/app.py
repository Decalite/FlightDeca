"""FlightDeca - Flask web app that serves the trained Random Forest model.

Run:  python app.py      then open http://127.0.0.1:5000
"""
import json
import os
from datetime import datetime

import joblib
import numpy as np
import pandas as pd
from flask import Flask, jsonify, render_template, request

from features import build_features

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "model", "flightdeca_model.joblib")
META_PATH = os.path.join(BASE_DIR, "model", "model_info.json")

app = Flask(__name__)

if not (os.path.exists(MODEL_PATH) and os.path.exists(META_PATH)):
    raise SystemExit("Model not found. Run `python train.py` first.")

model = joblib.load(MODEL_PATH)
with open(META_PATH) as f:
    META = json.load(f)


def parse_request(data):
    """Validate user input and return (clean_dict, error_message)."""
    required = ["airline", "source", "destination", "date", "dep_time",
                "duration_hours", "duration_minutes", "stops"]
    for key in required:
        if str(data.get(key, "")).strip() == "":
            return None, f"Missing field: {key}"

    if data["airline"] not in META["airlines"]:
        return None, "Unknown airline."
    if data["source"] not in META["cities"] or data["destination"] not in META["cities"]:
        return None, "Unknown city."
    if data["source"] == data["destination"]:
        return None, "Source and destination must be different."

    try:
        datetime.strptime(data["date"], "%Y-%m-%d")
        datetime.strptime(data["dep_time"], "%H:%M")
        hours, minutes = int(data["duration_hours"]), int(data["duration_minutes"])
        stops = int(data["stops"])
    except ValueError:
        return None, "Invalid date, time or number."

    if not (0 <= hours <= 30 and 0 <= minutes <= 59):
        return None, "Duration out of range."
    duration = hours * 60 + minutes
    if duration < 30:
        return None, "Duration must be at least 30 minutes."
    if not (0 <= stops <= META["max_stops"]):
        return None, f"Stops must be between 0 and {META['max_stops']}."

    return {
        "Airline": data["airline"], "Source": data["source"],
        "Destination": data["destination"], "Date_of_Journey": data["date"],
        "Dep_Time": data["dep_time"], "Duration_Min": duration, "Total_Stops": stops,
    }, None


@app.route("/")
def index():
    return render_template("index.html", meta=META)


@app.route("/api/model-info")
def model_info():
    return jsonify(META)


@app.route("/api/predict", methods=["POST"])
def predict():
    data = request.get_json(silent=True) or request.form.to_dict()
    clean, error = parse_request(data)
    if error:
        return jsonify({"error": error}), 400

    X = build_features(pd.DataFrame([clean]))
    fare = float(model.predict(X)[0])

    # Spread of the individual trees' predictions (10th-90th percentile).
    # This shows how much the trees disagree; it is NOT a statistical confidence interval.
    Xt = model.named_steps["prep"].transform(X)
    tree_preds = np.array([t.predict(Xt)[0] for t in model.named_steps["rf"].estimators_])
    low, high = np.percentile(tree_preds, [10, 90])

    return jsonify({
        "predicted_fare": int(round(fare)),
        "tree_spread_low": int(round(low)),
        "tree_spread_high": int(round(high)),
        "currency": "INR",
        "n_trees": int(len(tree_preds)),
        "synthetic_model": META["synthetic"],
    })


if __name__ == "__main__":
    # PORT env var lets hosting platforms choose the port
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
