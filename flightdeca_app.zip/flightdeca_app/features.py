"""Shared feature engineering for FlightDeca.

The SAME function is used while training and while predicting, so the model
always sees inputs prepared in exactly the same way.

Expected raw columns:
    Airline, Source, Destination   -> text (categorical)
    Date_of_Journey                -> "YYYY-MM-DD"
    Dep_Time                       -> "HH:MM" (24-hour)
    Duration_Min                   -> flight duration in minutes
    Total_Stops                    -> 0, 1, 2, 3 ...
    Price                          -> target (only needed for training)
"""
import pandas as pd

CATEGORICAL = ["Airline", "Source", "Destination"]
NUMERIC = [
    "Journey_Day",
    "Journey_Month",
    "Journey_Weekday",
    "Dep_Hour",
    "Dep_Minute",
    "Duration_Min",
    "Total_Stops",
]
FEATURES = CATEGORICAL + NUMERIC


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    """Turn raw journey details into the numeric/categorical features the model uses."""
    out = pd.DataFrame(index=df.index)

    out["Airline"] = df["Airline"].astype(str)
    out["Source"] = df["Source"].astype(str)
    out["Destination"] = df["Destination"].astype(str)

    date = pd.to_datetime(df["Date_of_Journey"], format="%Y-%m-%d")
    out["Journey_Day"] = date.dt.day
    out["Journey_Month"] = date.dt.month
    out["Journey_Weekday"] = date.dt.weekday  # Monday = 0

    dep = pd.to_datetime(df["Dep_Time"], format="%H:%M")
    out["Dep_Hour"] = dep.dt.hour
    out["Dep_Minute"] = dep.dt.minute

    out["Duration_Min"] = df["Duration_Min"].astype(int)
    out["Total_Stops"] = df["Total_Stops"].astype(int)

    return out[FEATURES]
