"""Train the FlightDeca Random Forest model.

Usage:
    python train.py                 # uses data/flights.csv (creates synthetic demo data if missing)
    python train.py --data my.csv   # use your own dataset
"""
import argparse
import json
import os

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

from features import CATEGORICAL, NUMERIC, build_features

MODEL_PATH = "model/flightdeca_model.joblib"
META_PATH = "model/model_info.json"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data/flights.csv")
    args = parser.parse_args()

    synthetic = False
    if not os.path.exists(args.data):
        from generate_sample_data import generate
        os.makedirs(os.path.dirname(args.data) or ".", exist_ok=True)
        generate().to_csv(args.data, index=False)
        open("data/.synthetic", "w").close()
        synthetic = True
        print(f"{args.data} not found -> created SYNTHETIC demo data.")
    elif os.path.basename(args.data) == "flights.csv" and os.path.exists("data/.synthetic"):
        synthetic = True

    df = pd.read_csv(args.data)
    X = build_features(df)
    y = df["Price"]

    # 80 / 20 split with a fixed seed so results are reproducible
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Pre-processing: one-hot encode categorical columns, pass numeric columns through
    prep = ColumnTransformer([
        ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), CATEGORICAL),
        ("num", "passthrough", NUMERIC),
    ])
    model = Pipeline([
        ("prep", prep),
        ("rf", RandomForestRegressor(
            n_estimators=150, min_samples_leaf=3, random_state=42, n_jobs=-1)),
    ])
    model.fit(X_train, y_train)

    # Evaluation on the held-out test set
    pred = model.predict(X_test)
    mae = float(mean_absolute_error(y_test, pred))
    rmse = float(np.sqrt(mean_squared_error(y_test, pred)))
    r2 = float(r2_score(y_test, pred))

    # Feature importance, summed back to the original (pre one-hot) columns
    names = model.named_steps["prep"].get_feature_names_out()
    imps = model.named_steps["rf"].feature_importances_
    importance = {}
    for name, imp in zip(names, imps):
        original = name[len("num__"):] if name.startswith("num__") else next(
            c for c in CATEGORICAL if name.startswith(f"cat__{c}_"))
        importance[original] = importance.get(original, 0.0) + float(imp)
    importance = dict(sorted(importance.items(), key=lambda kv: kv[1], reverse=True))

    meta = {
        "data_source": "SYNTHETIC demo data (not real fares)" if synthetic else args.data,
        "synthetic": synthetic,
        "n_train": int(len(X_train)),
        "n_test": int(len(X_test)),
        "metrics": {"MAE": round(mae, 2), "RMSE": round(rmse, 2), "R2": round(r2, 4)},
        "feature_importance": {k: round(v, 4) for k, v in importance.items()},
        "airlines": sorted(df["Airline"].unique().tolist()),
        "cities": sorted(set(df["Source"]) | set(df["Destination"])),
        "max_stops": int(df["Total_Stops"].max()),
    }

    os.makedirs("model", exist_ok=True)
    joblib.dump(model, MODEL_PATH, compress=3)
    with open(META_PATH, "w") as f:
        json.dump(meta, f, indent=2)

    print(f"Train rows: {len(X_train)} | Test rows: {len(X_test)}")
    print(f"MAE: {mae:.2f} | RMSE: {rmse:.2f} | R2: {r2:.4f}")
    print(f"Saved model -> {MODEL_PATH}")


if __name__ == "__main__":
    main()
